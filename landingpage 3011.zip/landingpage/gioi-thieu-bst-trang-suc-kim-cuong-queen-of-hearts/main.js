$(function(){

    $('.lp-content_bottom-content-2').find('.right').find('iframe').css({
      'height': $('.lp-content_bottom-content-2').find('.right').find('iframe').width() * 480 / 853
    });
  
    wow = new WOW({
      boxClass:     'wow',      // default
      animateClass: 'animated', // default
      offset: 50,
      mobile:       true,       // default
      live:         true        // default
    })
    wow.init();
  
  });